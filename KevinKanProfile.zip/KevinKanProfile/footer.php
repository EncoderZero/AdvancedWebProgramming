<?php /* Written By: Kevin Kan
	Footer file holds all closes for header file and copyright information*/ ?>
<footer>
	<p>Copy Right Kevin Kan 2013</p>
	<button id='toggleMobileDesktop' value="<?php echo ($isMobile==false) ? "mobile" : "desktop" ; ?>">Go To <?php echo ($isMobile==false) ? "Mobile" : "Desktop" ; ?> Site</button>
	<?php //site change above is controled by jquery file?>
</footer>
</body>
</html>